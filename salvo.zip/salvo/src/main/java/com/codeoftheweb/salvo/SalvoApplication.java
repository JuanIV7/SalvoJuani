package com.codeoftheweb.salvo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository basededatos ){
		return (args) -> {
			Player player1 = new Player("juanivillalba@outlook.com");
			Player player2 = new Player("lionelmessi@gmail.com");
            basededatos.save(player1);
            basededatos.save(player2);
 		};
	}
}
